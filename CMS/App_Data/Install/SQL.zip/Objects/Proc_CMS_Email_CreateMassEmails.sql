SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_Email_CreateMassEmails]
	@EmailID int,
	@SiteID int,
	@users ntext,
	@roles ntext,
	@Everyone bit
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRANSACTION

	IF @Everyone = 0
	BEGIN
		IF @SiteID > 0
		BEGIN
			INSERT INTO CMS_EmailUser (EmailID, UserID, Status)
			SELECT DISTINCT @EmailID, UserID, 1 FROM CMS_User WHERE ((@users LIKE '%;'+cast(UserID as nvarchar(250))+';%')
			OR (UserID IN (SELECT UserID FROM View_CMS_UserRole_Joined WHERE (@roles LIKE '%;'+cast(RoleID as nvarchar(250))+';%' AND SiteID = @SiteID)))
			) 
			AND (NOT (Email IS NULL OR Email = ''));
		END
		ELSE
		BEGIN
			INSERT INTO CMS_EmailUser (EmailID, UserID, Status)
			SELECT DISTINCT @EmailID, UserID, 1 FROM CMS_User WHERE ((@users LIKE '%;'+cast(UserID as nvarchar(250))+';%')
			OR (UserID IN (SELECT UserID FROM View_CMS_UserRole_Joined WHERE (@roles LIKE '%;'+cast(RoleID as nvarchar(250))+';%')))
			)
			AND (NOT (Email IS NULL OR Email = ''));
		END
	END
	ELSE
	BEGIN
		if @SiteID > 0
		BEGIN
			/* Select all users of specified site with entered e-mail address */
			INSERT INTO CMS_EmailUser (EmailID, UserID, Status)
			SELECT DISTINCT  @EmailID, CMS_User.UserID, 1 FROM CMS_User INNER JOIN CMS_UserSite ON	CMS_User.UserID = CMS_UserSite.UserID
			WHERE (NOT (Email IS NULL OR Email = '') AND SiteID = @SiteID);
		END
		ELSE
		BEGIN
			/* Select all users with entered e-mail address */
			INSERT INTO CMS_EmailUser (EmailID, UserID, Status)
			SELECT DISTINCT @EmailID, UserID, 1 FROM CMS_User
			WHERE (NOT (Email IS NULL OR Email = ''));
		END
	END

	/* Set pattern e-mail's status as 'waiting' so it is prepared to be sent  */
	UPDATE CMS_Email SET EmailStatus = 1 WHERE EmailID = @EmailID;

	COMMIT TRANSACTION
END
GO
