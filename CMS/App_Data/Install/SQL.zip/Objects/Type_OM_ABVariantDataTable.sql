CREATE TYPE [dbo].[Type_OM_ABVariantDataTable] AS TABLE(
	[ABVariantGUID] [uniqueidentifier] NOT NULL,
	[ABVariantDisplayName] [nvarchar](100) NOT NULL,
	[ABVariantIsOriginal] [bit] NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[ABVariantGUID] ASC
)
)
GO
